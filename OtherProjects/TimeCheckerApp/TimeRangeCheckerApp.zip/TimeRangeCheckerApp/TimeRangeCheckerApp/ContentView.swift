//
//  ContentView.swift
//  TimeRangeCheckerApp
//
//  Created by Kane on 2025/01/31.
//

import SwiftUI
import SwiftData

// MARK: - メインビュー
struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \TimeCheckModel.timestamp, order: .reverse) var timeChecks: [TimeCheckModel]
    
    @State private var startTime = 0
    @State private var endTime = 0
    @State private var checkTime = 0
    @State private var showingResult = false
    @State private var checkResult = false
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("時間入力")) {
                    Picker("開始時刻", selection: $startTime) {
                        ForEach(0..<24) { hour in
                            Text("\(hour)時").tag(hour)
                        }
                    }
                    
                    Picker("終了時刻", selection: $endTime) {
                        ForEach(0..<24) { hour in
                            Text("\(hour)時").tag(hour)
                        }
                    }
                    
                    Picker("確認時刻", selection: $checkTime) {
                        ForEach(0..<24) { hour in
                            Text("\(hour)時").tag(hour)
                        }
                    }
                }
                
                Section {
                    Button("時間範囲を確認") {
                        checkResult = TimeChecker.isTimeInRange(
                            startTime: startTime,
                            endTime: endTime,
                            checkTime: checkTime
                        )
                        saveCheck()
                        showingResult = true
                    }
                }
                
                NavigationLink("履歴を表示", destination: HistoryView())
            }
            .navigationTitle("時間範囲チェッカー")
            .alert("確認結果", isPresented: $showingResult) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(checkResult ? "指定された時間は範囲内です" : "指定された時間は範囲外です")
            }
        }
    }
    
    private func saveCheck() {
        let newCheck = TimeCheckModel(
            startTime: startTime,
            endTime: endTime,
            checkTime: checkTime,
            result: checkResult
        )
        modelContext.insert(newCheck)
    }
}
