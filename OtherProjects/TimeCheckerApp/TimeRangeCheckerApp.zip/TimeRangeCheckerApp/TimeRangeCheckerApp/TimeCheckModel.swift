//
//  TimeCheckModel.swift
//  TimeRangeCheckerApp
//
//  Created by Kane on 2025/01/31.
//

import SwiftUI
import SwiftData

// MARK: - データモデル
@Model
class TimeCheckModel {
    var id: UUID
    var startTime: Int
    var endTime: Int
    var checkTime: Int
    var result: Bool
    var timestamp: Date
    
    init(startTime: Int, endTime: Int, checkTime: Int, result: Bool) {
        self.id = UUID()
        self.startTime = startTime
        self.endTime = endTime
        self.checkTime = checkTime
        self.result = result
        self.timestamp = Date()
    }
}

// MARK: - 時間チェックロジック
struct TimeChecker {
    static func isTimeInRange(startTime: Int, endTime: Int, checkTime: Int) -> Bool {
        // 同じ時刻の場合
        if startTime == endTime {
            return checkTime == startTime
        }
        
        // 深夜をまたぐ場合
        if startTime > endTime {
            return checkTime >= startTime || checkTime < endTime
        }
        
        // 通常の場合
        return checkTime >= startTime && checkTime < endTime
    }
}
