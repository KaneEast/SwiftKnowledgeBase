//
//  HistoryView.swift
//  TimeRangeCheckerApp
//
//  Created by Kane on 2025/01/31.
//

import SwiftUI
import SwiftData

// MARK: - 履歴ビュー
struct HistoryView: View {
    @Query(sort: \TimeCheckModel.timestamp, order: .reverse) var checks: [TimeCheckModel]
    
    var body: some View {
        List(checks) { check in
            VStack(alignment: .leading, spacing: 8) {
                Text("確認時刻: \(check.checkTime)時")
                    .font(.headline)
                Text("範囲: \(check.startTime)時 - \(check.endTime)時")
                Text("結果: \(check.result ? "範囲内" : "範囲外")")
                Text("確認日時: \(check.timestamp, formatter: itemFormatter)")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding(.vertical, 4)
        }
        .navigationTitle("履歴")
    }
}

// MARK: - 日付フォーマッター
private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    formatter.locale = Locale(identifier: "ja_JP")
    return formatter
}()
