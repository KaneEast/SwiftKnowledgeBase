//
//  TimeRangeCheckerApp.swift
//  TimeRangeCheckerApp
//
//  Created by Kane on 2025/01/31.
//

import SwiftUI
import SwiftData

@main
struct TimeRangeCheckerApp: App {
    let container: ModelContainer
    
    init() {
        do {
            container = try ModelContainer(for: TimeCheckModel.self)
        } catch {
            fatalError("ModelContainer の初期化に失敗しました: \(error)")
        }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(container)
    }
}
